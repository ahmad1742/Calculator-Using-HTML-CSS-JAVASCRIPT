let currentDisplay = '';
document.querySelector('#display').value = currentDisplay;